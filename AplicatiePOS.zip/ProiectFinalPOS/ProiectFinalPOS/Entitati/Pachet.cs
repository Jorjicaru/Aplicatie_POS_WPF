﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProiectFinalPOS.Entitati
{
    public class Pachet : ProdusAbstract, IComparable<Pachet>
    {
        public List<IPackageable> elem_pachet = new List<IPackageable>();
        public Pachet(int id, string denumire, int codIntern, int pret, string categorie)
            : base(id, denumire, codIntern, pret, categorie)
        {

        }
        public override void Afisare1()
        {
            Console.WriteLine(Id + " " + Denumire + " " + CodIntern + " " + Pret + " " + Categorie);
        }
        public override bool canAddToPackage(Pachet pachet)
        {
            return true;
        }
        public void Adauga(IPackageable el)
        {
            elem_pachet.Add(el);
        }

        public int NumaraProduse()  //counts the products
        {
            int k = 0;
            foreach (IPackageable el in elem_pachet)
                if (el is Produs)
                    k++; //count
            return k;
        }

        public int PretTotal() //sum the prices of products and servicces
        {
            int total = 0;
            foreach (IPackageable el in elem_pachet)
                if (el is ProdusAbstract pa)
                    total = total + pa.Pret;
            return total;
        }

        public int CompareTo(Pachet pk)  //sort a package by price
        {
            if (pk == null)
                return 1;
            return this.PretTotal().CompareTo(pk.PretTotal());
        }
    }
}