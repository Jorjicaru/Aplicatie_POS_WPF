﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProiectFinalPOS.Entitati
{
    public interface IPackageable
    {
        bool canAddToPackage(Pachet pachet);
    }
}
