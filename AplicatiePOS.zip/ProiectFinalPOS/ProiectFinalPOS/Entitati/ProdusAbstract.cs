﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ProiectFinalPOS.Entitati
{
    [XmlRoot("ProdusAbstractParticularizat")]
    public abstract class ProdusAbstract : IPackageable
    {
        /* 
        int Id { get; set; }
        public string Denumire { get; set; }
        public int CodIntern { get; set; }
        public int  Pret { get; set; }
        public string Categorie { get; set; }
        */

        [XmlElement("ID")]
        public int Id { get; set; }

        [XmlElement("Denumire")]
        public string Denumire { get; set; }

        [XmlElement("CodulIntern")]
        public int CodIntern { get; set; }

        [XmlElement("Pret")]
        public int Pret { get; set; }

        [XmlElement("Categorie")]
        public string Categorie { get; set; }

        public ProdusAbstract(int id, string denumire, int codIntern, int pret, string categorie)
        {
            Id = id;
            Denumire = denumire;
            CodIntern = codIntern;
            Pret = pret;
            Categorie = categorie;
        }

        public ProdusAbstract()
        {

        }

        public abstract void Afisare1();

        public virtual void Afisare2()
        {
            Console.Write(Id + " " + Denumire + " " + CodIntern + " " + Pret + " " + Categorie + " ");
        }

        public virtual bool canAddToPackage(Pachet pachet)
        {
            throw new NotImplementedException();
        }
    }
}
