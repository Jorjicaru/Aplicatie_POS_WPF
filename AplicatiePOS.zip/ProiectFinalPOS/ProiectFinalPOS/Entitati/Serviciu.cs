﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ProiectFinalPOS.Entitati
{
    [XmlRoot("ServiciuParticularizat")]
    public class Serviciu : ProdusAbstract, IPackageable
    {
        //public int DurataReparatie { get; set; }

        [XmlElement("DurataReparatie")]
        public int DurataReparatie { get; set; }

        public Serviciu(int id, string denumire, int codIntern, int pret, string categorie, int durataReparatie) : base(id, denumire, codIntern, pret, categorie)
        {
            DurataReparatie = durataReparatie;
        }

        public Serviciu()
        {

        }

        public override void Afisare1()
        {
            Console.WriteLine(Id + " " + Denumire + " " + CodIntern + " " + Pret + " " + Categorie + " " + DurataReparatie);
        }

        public override void Afisare2()
        {
            base.Afisare2();
            Console.WriteLine(DurataReparatie);
        }

        public override string ToString()
        {
            return Id + " " + Denumire + " " + CodIntern + " " + Pret + " " + Categorie + " " + DurataReparatie + " ";
        }

        public static int CautaServiciu(Serviciu[] vS, int nServ, int codCautat)
        {
            int ok = 0; //presupun ca serviciul cu codul dat nu se afla in lista
            for (int i = 0; i < nServ; i++)
                if (codCautat == vS[i].Id)
                    ok = 1; //serviciul cu codul cautat este deja in lista
            return ok;
        }

        //polimorfism prin suprascrierea operatorilor/metodelor

        //Equals() este o metoda mostenita din clasa de baza Object.
        //Implicit, ea compara adresele din memorie ale obiectelor, nu valorile campurilor.
        //Noi dorim sa o suprascriem pentru a compara valorile atributelor(ex: Id, CodIntern).

        public override bool Equals(object obj)
        {
            bool ok = false;

            //verificam daca obiectul NNU este null si este de tip Produs
            if (obj is Serviciu s)
            {
                //comparam campurile Id si CodIntern
                if (Id == s.Id)
                    ok = true;
            }
            return ok;
        }

        //Operatorul == este un operator static
        //Implicit, el compara adresele din memorie ale obiectelor, nu valorile campurilor.
        //Noi dorim sa il suprascriem pentru a compara valorile atributelor(ex: Id, CodIntern).
        //IMPORTANT: Cand redefiniti ==, trebuie redefinit si !=, altfel compilatorul va genera o eroare.

        public static bool operator ==(Serviciu s1, Serviciu s2)
        {
            bool ok = false;

            if (ReferenceEquals(s1, s2)) // verifica daca adresele sunt identice
                ok = true;
            else
                if (!ReferenceEquals(s1, null) && !ReferenceEquals(s2, null))
                {
                    if (s1.Id == s2.Id)
                        ok = true;
                }
            return ok;
        }

        public static bool operator !=(Serviciu s1, Serviciu s2)
        {
            bool ok = false; //presupunem ca p1 si p2 NU sunt diferiti

            if (!(s1 == s2)) //daca sunt diferite
                ok = true;

            return ok;
        }

        public override bool canAddToPackage(Pachet pachet)
        {
            return true;
        }

        public void save2XML(string fileName)
        {
            XmlSerializer xs = new XmlSerializer(typeof(Serviciu));
            StreamWriter sw = new StreamWriter(fileName + ".xml");
            xs.Serialize(sw, this);
            sw.Close();
        }

        public Serviciu loadFromXML(string fileName)
        {
            XmlSerializer xs = new XmlSerializer(typeof(Serviciu));
            FileStream fs = new FileStream(fileName + ".xml", FileMode.Open);
            XmlReader reader = new XmlTextReader(fs);
            //deserializare cu crearea de obiect => constructor fara param
            Serviciu serviciu = (Serviciu)xs.Deserialize(reader);
            fs.Close();
            return serviciu;
        }
    }
}
