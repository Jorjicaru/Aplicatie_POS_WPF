﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ProiectFinalPOS.Entitati
{
    [XmlRoot("ProdusParticularizat")]
    public class Produs : ProdusAbstract, IComparable<Produs>, IPackageable
    {
        //public string Producator { get; set; }

        [XmlElement("Producator")]
        public string Producator { get; set; }

        public Produs(int id, string denumire, int codIntern, int pret, string categorie, string producator) : base(id, denumire, codIntern, pret, categorie)
        {
            Producator = producator;
        }

        public Produs()
        {

        }
        public override void Afisare1()
        {
            Console.WriteLine(Id + " " + Denumire + " " + CodIntern + " " + Pret + " " + Categorie + " " + Producator);
        }

        public override void Afisare2()
        {
            base.Afisare2();
            Console.WriteLine(Producator);
        }

        public override string ToString()
        {
            return Id + " " + Denumire + " " + CodIntern + " " + Pret + " " + Categorie + " " + Producator + " ";
        }

        public static int CautaProdus(Produs[] vP, int nProd, int codCautat)
        {
            int ok = 0; //presupun ca produsul cu codul dat nu se afla in lista
            for (int i = 0; i < nProd; i++)
                if (codCautat == vP[i].Id)
                    ok = 1; //produsul cu codul cautat este deja in lista
            return ok;
        }

        //polimorfism prin suprascrierea operatorilor/metodelor

        //Equals() este o metoda mostenita din clasa de baza Object.
        //Implicit, ea compara adresele din memorie ale obiectelor, nu valorile campurilor.
        //Noi dorim sa o suprascriem pentru a compara valorile atributelor(ex: Id, CodIntern).

        public override bool Equals(object obj)
        {
            bool ok = false;

            //verificam daca obiectul NNU este null si este de tip Produs
            if (obj is Produs p)
            {
                //comparam campurile Id
                if (Id == p.Id)
                    ok = true;
            }
            return ok;
        }

        //Operatorul == este un operator static
        //Implicit, el compara adresele din memorie ale obiectelor, nu valorile campurilor.
        //Noi dorim sa il suprascriem pentru a compara valorile atributelor(ex: Id, CodIntern).
        //IMPORTANT: Cand redefiniti ==, trebuie redefinit si !=, altfel compilatorul va genera o eroare.

        public static bool operator ==(Produs p1, Produs p2)
        {
            bool ok = false;

            if (ReferenceEquals(p1, p2)) // verifica daca adresele sunt identice
                ok = true;
            else
                if (!ReferenceEquals(p1, null) && !ReferenceEquals(p2, null))
                {
                    if (p1.Id == p2.Id) //comparam valori
                        ok = true;
                }
            return ok;
        }

        public static bool operator !=(Produs p1, Produs p2)
        {
            bool ok = false; //presupunem ca p1 si p2 NU sunt diferiti

            if (!(p1 == p2)) //daca sunt diferite
                ok = true;

            return ok;
        }

        public int CompareTo(Produs p) //o folosim la sortarea unui tablou
        {
            if (p == null)
                return 1;
            return Id.CompareTo(p.Id); //comparare dupa Id
        }

        public override bool canAddToPackage(Pachet pachet)
        {
            bool ok = true;
            if (pachet.NumaraProduse() > 1) //only 1 product in a package
                ok = false;
            return ok;
        }

        public void save2XML(string fileName)
        {
            XmlSerializer xs = new XmlSerializer(typeof(Produs));
            StreamWriter sw = new StreamWriter(fileName + ".xml");
            xs.Serialize(sw, this);
            sw.Close();
        }

        public Produs loadFromXML(string fileName)
        {
            XmlSerializer xs = new XmlSerializer(typeof(Produs));
            FileStream fs = new FileStream(fileName + ".xml", FileMode.Open);
            XmlReader reader = new XmlTextReader(fs);
            //deserializare cu crearea de obiect => constructor fara param
            Produs produs = (Produs)xs.Deserialize(reader);
            fs.Close();
            return produs;
        }
    }
}