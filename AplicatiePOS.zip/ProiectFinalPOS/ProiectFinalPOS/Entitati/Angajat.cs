﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProiectFinalPOS.Entitati
{
    public class Angajat : Persoana
    {
        public int SalariuBaza { get; set; }

        public Angajat(int id, string nume, int salariuBaza)
            : base(id, nume)
        {
            SalariuBaza = salariuBaza;
        }

        public override void Afisare()
        {
            base.Afisare();
            Console.WriteLine(SalariuBaza);
        }

        public int CalculSalariu(int salariuBaza, int bonus)
        {
            return salariuBaza + bonus;
        }

        public int CalculSalariu(int salariuBaza, int bonus, int impozit)
        {
            return salariuBaza + bonus - impozit;
        }
    }
}
