﻿using ProiectFinalPOS.Aplicatie;
using ProiectFinalPOS.Entitati;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProiectFinalPOS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private PacheteManager pacheteManager = new PacheteManager();
        private AngajatiManager angajatiManager = new AngajatiManager();
        private ClientiManager clientiManager = new ClientiManager();

        public MainWindow()
        {
            InitializeComponent();
        }

        // ==========================================
        // SECTIUNEA 1: PACHETE
        // ==========================================
        private void btnIncarcaDate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string pathProduse = System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, "Produse.xml");
                string pathServicii = System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, "Servicii.xml");

                System.Xml.XmlDocument docP = new System.Xml.XmlDocument();
                docP.Load(pathProduse);
                System.Xml.XmlNodeList listaP = docP.SelectNodes("/Produse/Produs");
                foreach (System.Xml.XmlNode node in listaP)
                {
                    pacheteManager.pM.elemente.Add(new Produs(
                        Convert.ToInt32(node["id"].InnerText),
                        node["denumire"].InnerText,
                        Convert.ToInt32(node["codIntern"].InnerText),
                        Convert.ToInt32(node["pret"].InnerText),
                        node["categorie"].InnerText,
                        node["producator"].InnerText));
                }

                System.Xml.XmlDocument docS = new System.Xml.XmlDocument();
                docS.Load(pathServicii);
                System.Xml.XmlNodeList listaS = docS.SelectNodes("/Servicii/Serviciu");
                foreach (System.Xml.XmlNode node in listaS)
                {
                    pacheteManager.sM.elemente.Add(new Serviciu(
                        Convert.ToInt32(node["id"].InnerText),
                        node["denumire"].InnerText,
                        Convert.ToInt32(node["codIntern"].InnerText),
                        Convert.ToInt32(node["pret"].InnerText),
                        node["categorie"].InnerText,
                        Convert.ToInt32(node["durataReparatie"].InnerText)));
                }

                ActualizeazaTabelProduse();
                ActualizeazaTabelServicii();
                MessageBox.Show("Datele din fișierele XML au fost încărcate în memorie cu succes!", "Succes");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Asigura-te ca fisierele XML sunt in proiect pe 'Copy always'. Eroare: {ex.Message}", "Eroare");
            }
        }

        private void btnAsambleazaPachete_Click(object sender, RoutedEventArgs e)
        {
            if (pacheteManager.pM.elemente.Count == 0 && pacheteManager.sM.elemente.Count == 0)
            {
                MessageBox.Show("Încarcă mai întâi XML-urile (Butonul A)!"); return;
            }

            Pachet pachetAuto = new Pachet(999, "Pachet Promotional Generat", 111, 400, "Promotional");

            foreach (Produs p in pacheteManager.pM.elemente.OfType<Produs>())
            {
                if (p.canAddToPackage(pachetAuto)) pachetAuto.Adauga(p);
            }
            foreach (Serviciu s in pacheteManager.sM.elemente.OfType<Serviciu>())
            {
                if (s.canAddToPackage(pachetAuto)) pachetAuto.Adauga(s);
            }

            pacheteManager.pachete.Add(pachetAuto);
            ActualizeazaTabelPachete(pacheteManager.pachete);
        }

        private void btnAdaugaPachet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Pachet pk = new Pachet(
                    Convert.ToInt32(txtIdPachet.Text), txtDenumirePachet.Text,
                    Convert.ToInt32(txtCodPachet.Text), Convert.ToInt32(txtPretPachet.Text), txtCategoriePachet.Text);
                pacheteManager.pachete.Add(pk);
                ActualizeazaTabelPachete(pacheteManager.pachete);
            }
            catch { MessageBox.Show("Verificați corectitudinea datelor introduse!"); }
        }

        private void btnAfiseazaToate_Click(object sender, RoutedEventArgs e) { ActualizeazaTabelPachete(pacheteManager.pachete); }
        private void btnSortarePret_Click(object sender, RoutedEventArgs e) { pacheteManager.pachete.Sort(); ActualizeazaTabelPachete(pacheteManager.pachete); }
        private void btnFiltruPromotional_Click(object sender, RoutedEventArgs e) { ActualizeazaTabelPachete(pacheteManager.pachete.Where(p => p.Categorie == "Promotional").ToList()); }
        private void btnFiltruPret_Click(object sender, RoutedEventArgs e) { ActualizeazaTabelPachete(pacheteManager.pachete.Where(p => p.Pret <= 500).ToList()); }

        private void ActualizeazaTabelPachete(List<Pachet> lista)
        {
            dgPachete.ItemsSource = null;
            dgPachete.ItemsSource = lista.Select(p => new {
                p.Id,
                p.Denumire,
                p.CodIntern,
                p.Categorie,
                p.Pret,
                PretCalculat = p.PretTotal(),
                NumarProduseInclus = p.NumaraProduse()
            }).ToList();
        }

        // ==========================================
        // SECTIUNEA 2 & 3: PRODUSE SI SERVICII 
        // ==========================================
        private void btnAdaugaProdus_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Produs pNou = new Produs(
                    Convert.ToInt32(txtIdProdus.Text), txtDenumireProdus.Text, Convert.ToInt32(txtCodProdus.Text),
                    Convert.ToInt32(txtPretProdus.Text), txtCatProdus.Text, txtProducatorProdus.Text);

                pacheteManager.pM.elemente.Add(pNou);
                ActualizeazaTabelProduse();
            }
            catch { MessageBox.Show("Verificați datele produsului!"); }
        }

        private void btnAdaugaServiciu_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Serviciu sNou = new Serviciu(
                    Convert.ToInt32(txtIdServiciu.Text), txtDenumireServiciu.Text, Convert.ToInt32(txtCodServiciu.Text),
                    Convert.ToInt32(txtPretServiciu.Text), txtCatServiciu.Text, Convert.ToInt32(txtDurataServiciu.Text));

                pacheteManager.sM.elemente.Add(sNou);
                ActualizeazaTabelServicii();
            }
            catch { MessageBox.Show("Verificați datele serviciului!"); }
        }

        private void ActualizeazaTabelProduse()
        {
            dgProduse.ItemsSource = null;
            dgProduse.ItemsSource = pacheteManager.pM.elemente;
        }

        private void ActualizeazaTabelServicii()
        {
            dgServicii.ItemsSource = null;
            dgServicii.ItemsSource = pacheteManager.sM.elemente;
        }

        private void btnIncarcaProduseXML_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                pacheteManager.pM.CitireDinFisierulXML();
                ActualizeazaTabelProduse();
                MessageBox.Show("Produsele au fost încărcate din XML!", "Succes");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eroare la încărcare XML: " + ex.Message, "Eroare");
            }
        }

        private void btnIncarcaServiciiXML_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                pacheteManager.sM.CitireServiciiDinXML();
                ActualizeazaTabelServicii();
                MessageBox.Show("Serviciile au fost încărcate din XML!", "Succes");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eroare la încărcare XML: " + ex.Message, "Eroare");
            }
        }

        // ==========================================
        // SECTIUNEA 4: ANGAJATI
        // ==========================================
        private void btnAdaugaAngajat_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // AngajatiManager are limită fixă vA[10] din codul tău de bază
                if (angajatiManager.nA >= 10)
                {
                    MessageBox.Show("Capacitate maximă de angajați (10) a fost atinsă!", "Avertisment");
                    return;
                }

                int id = Convert.ToInt32(txtIdAngajat.Text);
                string nume = txtNumeAngajat.Text;
                int salariu = Convert.ToInt32(txtSalariuAngajat.Text);

                // Instantiem angajatul si il punem in array
                angajatiManager.vA[angajatiManager.nA] = new Angajat(id, nume, salariu);
                angajatiManager.nA++; // Incrementam contorul

                // Preluam din array doar angajatii valabili (de la 0 la nA) si aplicam functiile tale polimorfice pentru vizualizare
                dgAngajati.ItemsSource = null;
                dgAngajati.ItemsSource = angajatiManager.vA.Take(angajatiManager.nA).Select(a => new {
                    a.Id,
                    a.Nume,
                    a.SalariuBaza,
                    SalariuBrut = a.CalculSalariu(a.SalariuBaza, 1000), // Apeleaza functia de 2 parametri
                    SalariuNet = a.CalculSalariu(a.SalariuBaza, 1000, 4000) // Apeleaza functia de 3 parametri
                }).ToList();
            }
            catch { MessageBox.Show("Verificați datele angajatului introduse!"); }
        }

        // ==========================================
        // SECTIUNEA 5: CLIENTI
        // ==========================================
        private void btnAdaugaClient_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (clientiManager.nC >= 10)
                {
                    MessageBox.Show("Capacitate maximă de clienți (10) a fost atinsă!", "Avertisment");
                    return;
                }

                clientiManager.vC[clientiManager.nC] = new Client(
                    Convert.ToInt32(txtIdClient.Text), txtNumeClient.Text, Convert.ToInt32(txtVarstaClient.Text));
                clientiManager.nC++;

                dgClienti.ItemsSource = null;
                dgClienti.ItemsSource = clientiManager.vC.Take(clientiManager.nC).ToList();
            }
            catch { MessageBox.Show("Verificați datele clientului introduse!"); }
        }
    }
}
