﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProiectFinalPOS.Entitati;

namespace ProiectFinalPOS.Aplicatie
{
    public class AngajatiManager
    {
        public int i, nA, Id, SalariuBaza;
        public string Nume;
        public Angajat[] vA = new Angajat[10];

        public void CitireaAngajatilor()
        {
            Console.Write("Cati angajati?");
            nA = Convert.ToInt32(Console.ReadLine());
            for (i = 0; i < nA; i++)
            {
                Console.Write("ID angajat: ");
                Id = Convert.ToInt32(Console.ReadLine());
                Console.Write("Nume angajat: ");
                Nume = Console.ReadLine();
                Console.Write("Salariu de baza: ");
                SalariuBaza = Convert.ToInt32(Console.ReadLine());
                vA[i] = new Angajat(Id, Nume, SalariuBaza);
            }
            Console.WriteLine();
        }

        public void AfisareaTuturorAngajatilor()
        {
            Console.WriteLine("*************** LISTA DE ANGAJATI ***************");
            for (i = 0; i < nA; i++)
                vA[i].Afisare();
            Console.WriteLine();
        }

        public void AfisareaSalariilorAngajatilor()
        {
            Console.WriteLine("*************** SALARIILE ANGAJATIILOR ***************");
            for (i = 0; i < nA; i++)
            {
                int brut = vA[i].CalculSalariu(vA[i].SalariuBaza, 1000);
                int net = vA[i].CalculSalariu(vA[i].SalariuBaza, 1000, 4000);
                Console.WriteLine(vA[i].Nume + " are salariul brut " + brut + " si salariul net " + net);
            }
            Console.WriteLine();
        }
    }
}
