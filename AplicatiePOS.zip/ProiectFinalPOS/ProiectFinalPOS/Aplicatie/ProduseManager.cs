﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using ProiectFinalPOS.Entitati;

namespace ProiectFinalPOS.Aplicatie
{
    public class ProduseManager
    {
        public int nProd, i, j, Id, CodIntern, Pret;
        public string DenumireP, Producator, Categorie;
        public Produs[] vP = new Produs[10];

        public void CitireaProduselor()
        {
            Console.Write("Cate produse?");
            nProd = Convert.ToInt32(Console.ReadLine());

            j = 0;
            for (i = 0; i < nProd; i++)
            {
                Console.Write("Id produs: ");
                Id = Convert.ToInt32(Console.ReadLine());

                /* Varianta cu Equals
                public Produs pc = new Produs(Id, "", 0, 0, "", "");
                int ok = 0;
                for (int k = 0; k < j; k++)
                    if (vP[k].Equals(pc)) //apel Equals
                        ok = 1; //produse cu Id egal
                if (ok == 1)
                {
                    Console.WriteLine("Acest Id exista deja!");
                    i--
                    continue;
                }
                */

                /* Varianta cu ==
                public Produs pc = new Produs(Id, "", 0, 0, "", "");
                int ok = 0;
                for (int k = 0; k < j; k++)
                    if (vP[k] == pc) //apel ==
                        ok = 1; //produse cu Id egal
                if (ok == 1)
                {
                    Console.WriteLine("Acest Id exista deja!");
                    i--
                    continue;
                }
                */

                if (Produs.CautaProdus(vP, j, Id) == 1)
                {
                    Console.WriteLine("Acest Id exista deja!");
                    i--;
                    continue;
                }

                Console.Write("Denumire produs: ");
                DenumireP = Console.ReadLine();

                Console.Write("Cod produs: ");
                CodIntern = Convert.ToInt32(Console.ReadLine());

                Console.Write("Pret produs: ");
                Pret = Convert.ToInt32(Console.ReadLine());

                Console.Write("Categorie produs: ");
                Categorie = Console.ReadLine();

                Console.Write("Producator: ");
                Producator = Console.ReadLine();

                vP[j] = new Produs(Id, DenumireP, CodIntern, Pret, Categorie, Producator);
                j++;
            }
        }
        public void AfisareaTuturorProduselor()
        {
            Console.WriteLine("*************** LISTA DE PRODUSE ***************");
            for (i = 0; i < j; i++)
                vP[i].Afisare2();
        }

        //polimorfism prin suprascrierea functiilor/metodelor - avem functii cu acelasi nume dar parametri diferiti

        //cautare dupa obiect
        public bool Contine(Produs p)
        {
            bool ok = false;
            for (int i = 0; i < j; i++)
                if (vP[i] == p) //folosim operatorul ==
                    ok = true;
            return ok;
        }

        //cautare dupa nume
        public bool Contine(string numeProdus)
        {
            bool ok = false;
            for (int i = 0; i < j; i++)
                if (vP[i].Denumire == numeProdus) //daca denumirea este identica cu numele produsului
                    ok = true;
            return ok;
        }

        //cautare dupa nume (returneata TOATE)
        public Produs[] Contine2(string numeProdus1)
        {
            Produs[] rezultate = new Produs[10];
            int k = 0;
            for (int i = 0; i < j; i++)
                if (vP[i].Denumire == numeProdus1)
                {
                    rezultate[k] = vP[i];
                    k++;
                }
            return rezultate;
        }

        public void Sorteaza()
        {
            Array.Sort(vP, 0, j); //sortam tabloul vP de la 0 la j
        }

        //******************** FISIERE ********************
        public List<ProdusAbstract> elemente = new List<ProdusAbstract>(); //elemente este in loc de vP
        public void CitireDinFisierulXML()
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, "Produse.xml"));
            XmlNodeList lista = doc.SelectNodes("/Produse/Produs");

            foreach (XmlNode node in lista)
            {
                Id = Convert.ToInt32(node["id"].InnerText);
                DenumireP = node["denumire"].InnerText;
                CodIntern = Convert.ToInt32(node["codIntern"].InnerText);
                Pret = Convert.ToInt32(node["pret"].InnerText);
                Categorie = node["categorie"].InnerText;
                Producator = node["producator"].InnerText;

                elemente.Add(new Produs(Id, DenumireP, CodIntern, Pret, Categorie, Producator));
            }
        }

        public void AfisareDinLista()
        {
            Console.WriteLine("Produsele din lista sunt: ");
            foreach (ProdusAbstract p in elemente) //pentru fiecare produs din lista elemente
                p.Afisare2(); //afisam toate informatiile
        }

        //************************** INTEROGARI ********************

        public void Interogare1()
        {
            IEnumerable<ProdusAbstract> interogare_linq =
                from el in elemente
                where el.Categorie == "IT"
                orderby el.Denumire
                select el;

            Console.WriteLine("Produsele din categoria IT extrase sunt:");
            foreach (ProdusAbstract p in interogare_linq)
                Console.WriteLine(p.ToString());
        }

        public void Interogare2()
        {
            IEnumerable<ProdusAbstract> interogare_linq =
                from el in elemente
                where el.Categorie == "IT" && el.Pret <= 200
                orderby el.Denumire
                select el;

            Console.WriteLine("Produsele din categoria IT cu pretul mai mic sau egal cu 200 extrase sunt:");
            foreach (ProdusAbstract p in interogare_linq)
                Console.WriteLine(p.ToString());
        }

        public void Interogare3()
        {
            var interogare_linq =
            from elem in elemente
            orderby elem.Denumire
            group elem by elem.Categorie into gr
            select gr;
            foreach (var gr in interogare_linq)
            {
                Console.WriteLine("Categoria " + gr.Key + " :");
                foreach (ProdusAbstract elem in gr)
                {
                    Console.WriteLine(elem.ToString());
                }
            }
        }
    }
}
