﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProiectFinalPOS.Entitati;

namespace ProiectFinalPOS.Aplicatie
{
    public class ClientiManager
    {
        public int i, nC, Id, Varsta;
        public string Nume;
        public Client[] vC = new Client[10];

        public void CitireaClientilor()
        {
            Console.Write("Cati clienti?");
            nC = Convert.ToInt32(Console.ReadLine());
            for (i = 0; i < nC; i++)
            {
                Console.Write("ID client: ");
                Id = Convert.ToInt32(Console.ReadLine());
                Console.Write("Nume client: ");
                Nume = Console.ReadLine();
                Console.Write("Varsta: ");
                Varsta = Convert.ToInt32(Console.ReadLine());
                vC[i] = new Client(Id, Nume, Varsta);
            }
        }
        public void AfisareaClientilor()
        {
            Console.WriteLine();
            Console.WriteLine("*************** LISTA DE CLIENTI ***************");
            for (i = 0; i < nC; i++)
                vC[i].Afisare();
        }
    }
}
