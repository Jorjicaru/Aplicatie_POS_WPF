﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProiectFinalPOS.Entitati;

namespace ProiectFinalPOS.Aplicatie
{
    public class PacheteManager
    {
        public List<Pachet> pachete = new List<Pachet>();
        public int i, nrPack, Id, CodIntern, Pret;
        public string Denumire, Categorie;
        public ProduseManager pM = new ProduseManager();
        public ServiciiManager sM = new ServiciiManager();

        public void CitirePachete()
        {
            Console.WriteLine("Cate pachete doriti?");
            nrPack = Convert.ToInt32(Console.ReadLine());
            for (i = 0; i < nrPack; i++)
            {
                Console.WriteLine("Introduceti id-ul pachetului:");
                Id = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Introduceti denumirea pachetului: ");
                Denumire = Console.ReadLine();

                Console.WriteLine("Introduceti codul intern al pachetului:");
                CodIntern = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Introduceti pretul pachetului:");
                Pret = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Introduceti categoria pachetului: ");
                Categorie = Console.ReadLine();

                Pachet pk = new Pachet(Id, Denumire, CodIntern, Pret, Categorie);
                foreach (Produs p in pM.elemente)
                {
                    if (p.canAddToPackage(pk))
                        pk.Adauga(p); // adaugam produsul din lista numita elemente in pachet
                    else
                        Console.WriteLine("Produsul " + p.Denumire + " nu poate fi adaugat!");
                }

                foreach (Serviciu s in sM.elemente)
                {
                    if (s.canAddToPackage(pk))
                        pk.Adauga(s); // adaugam serviciul din lista numita elemente in pachet
                    else
                        Console.WriteLine("Serviciul " + s.Denumire + " nu poate fi adaugat!");
                }
                pachete.Add(pk); //adaugam pachetul in lista
            }
        }

        public void AfisarePachete()
        {
            Console.WriteLine("********* Pachetele sunt: *************");
            foreach (Pachet pk in pachete)
                pk.Afisare1();
        }

        public void AfisarePacheteSortate()
        {
            foreach (Pachet pk in pachete)
            {
                pk.PretTotal();
                Console.WriteLine("Pretul total este: " + pk.PretTotal());
            }
            pachete.Sort();
            Console.WriteLine("Pachetele sortate  dupa pret sunt: ");
            foreach (Pachet pk in pachete)
                pk.Afisare1();
        }
        public void Interogare1()
        {
            IEnumerable<Pachet> interogare_linq =
                from el in pachete
                where el.Categorie == "Promotional"
                orderby el.Denumire
                select el;
            Console.WriteLine("Pachetele din categoria promotional sunt: ");
            foreach (Pachet pk in interogare_linq)
                pk.Afisare1();
        }

        public void Interogare2()
        {
            IEnumerable<Pachet> interogare_linq =
                from el in pachete
                where el.Pret <= 500
                orderby el.Categorie
                select el;
            Console.WriteLine("Pachetele cu pretul mai mic egal cu 500 extrase sunt:");
            foreach (Pachet pk in interogare_linq)
                pk.Afisare1();
        }

        public void Interogare3()
        {
            var interogare_linq =
                from el in pachete
                orderby el.Denumire
                group el by el.Categorie into gr
                select gr;
            foreach (var gr in interogare_linq)
            {
                Console.WriteLine("Categoria" + gr.Key + " !");
                foreach (Pachet el in gr)
                {
                    el.Afisare1();
                }
            }
        }
    }
}