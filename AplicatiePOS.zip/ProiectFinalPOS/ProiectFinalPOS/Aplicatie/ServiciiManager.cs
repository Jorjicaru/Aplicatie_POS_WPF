﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using ProiectFinalPOS.Entitati;

namespace ProiectFinalPOS.Aplicatie
{
    public class ServiciiManager
    {
        public int nServ, i, j, Id, CodIntern, CodServiciu, DurataReparatie;
        public int Pret;
        public string DenumireS, Categorie;
        public Serviciu[] vS = new Serviciu[10];

        public void CitireaServiciilor()
        {
            Console.Write("Cate servicii?");
            nServ = Convert.ToInt32(Console.ReadLine());

            j = 0;
            for (i = 0; i < nServ; i++)
            {
                Console.Write("Id serviciu: ");
                Id = Convert.ToInt32(Console.ReadLine());

                /* Varianta cu Equals
                public Serviciu sc = new Serviciu(Id, "", 0, "");
                int ok = 0;
                for (int k = 0; k < j; k++)
                    if (vS[k].Equals(sc)) //apel Equals
                        ok = 1; //servicii cu Id egal
                if (ok == 1)
                {
                    Console.WriteLine("Acest Id exista deja!");
                    i--
                    continue;
                }
                */

                /* Varianta cu ==
                public Serviciu sc = new Serviciu(Id, "", 0, "");
                int ok = 0;
                for (int k = 0; k < j; k++)
                    if (vS[k] == sc) //apel ==
                        ok = 1; //servicii cu Id egal
                if (ok == 1)
                {
                    Console.WriteLine("Acest Id exista deja!");
                    i--
                    continue;
                }
                */

                if (Serviciu.CautaServiciu(vS, j, CodServiciu) == 1)
                {
                    Console.WriteLine("Acest Id exista deja!");
                    i--;
                    continue;
                }

                Console.Write("Denumire serviciu: ");
                DenumireS = Console.ReadLine();

                Console.Write("Cod serviciu: ");
                CodIntern = Convert.ToInt32(Console.ReadLine());

                Console.Write("Pret: ");
                Pret = Convert.ToInt32(Console.ReadLine());

                Console.Write("Categorie serviciu: ");
                Categorie = Console.ReadLine();

                Console.Write("Durata reparatiei: ");
                DurataReparatie = Convert.ToInt32(Console.ReadLine());



                vS[j] = new Serviciu(Id, DenumireS, CodIntern, Pret, Categorie, DurataReparatie);
                j++;
            }
        }
        public void AfisareaServiciilor()
        {
            Console.WriteLine("*************** LISTA DE SERVICII ***************");
            for (i = 0; i < j; i++)
                vS[i].Afisare2();
        }

        //polimorfism prin suprascrierea functiilor/metodelor - avem functii cu acelasi nume dar parametri diferiti

        //cautare dupa obiect
        public bool Contine(Serviciu s)
        {
            bool ok = false;
            for (int i = 0; i < j; i++)
                if (vS[i] == s) //folosim operatorul ==
                    ok = true;
            return ok;
        }

        //cautare dupa nume
        public bool Contine(string numeServiciu)
        {
            bool ok = false;
            for (int i = 0; i < j; i++)
                if (vS[i].Denumire == numeServiciu) //daca denumirea este identica cu numele produsului
                    ok = true;
            return ok;
        }

        //cautare dupa nume (returneata TOATE)
        public Serviciu[] Contine2(string numeServiciu1)
        {
            Serviciu[] rezultate = new Serviciu[10];
            int k = 0;
            for (int i = 0; i < j; i++)
                if (vS[i].Denumire == numeServiciu1)
                {
                    rezultate[k] = vS[i];
                    k++;
                }
            return rezultate;
        }

        //******************** FISIERE ********************
        public List<ProdusAbstract> elemente = new List<ProdusAbstract>();
        public void CitireServiciiDinXML()
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, "Servicii.xml"));
            XmlNodeList lista = doc.SelectNodes("/Servicii/Serviciu");

            foreach (XmlNode node in lista)
            {
                Id = Convert.ToInt32(node["id"].InnerText);
                DenumireS = node["denumire"].InnerText;
                CodIntern = Convert.ToInt32(node["codIntern"].InnerText);
                Pret = Convert.ToInt32(node["pret"].InnerText);
                Categorie = node["categorie"].InnerText;
                DurataReparatie = Convert.ToInt32(node["durataReparatie"].InnerText);

                elemente.Add(new Serviciu(Id, DenumireS, CodIntern, Pret, Categorie, DurataReparatie));
            }
        }

        public void AfisareServiciiXML()
        {
            Console.WriteLine("**********Servicii din XML + Lista**********");
            foreach (ProdusAbstract s in elemente)
                s.Afisare2();
        }

        //*********************** INTEROGARI ********************
        public void Interogare1()
        {
            IEnumerable<ProdusAbstract> interogare_linq =
                from el in elemente
                where el.Categorie == "Reparatie"
                orderby el.Denumire
                select el;

            Console.WriteLine("Serviciile din categoria reparatie extrase sunt:");
            foreach (ProdusAbstract s in interogare_linq)
                Console.WriteLine(s.ToString());
        }

        public void Interogare2()
        {
            IEnumerable<ProdusAbstract> interogare_linq =
                from el in elemente
                where el.Categorie == "Reparatie" && el.Pret <= 200
                orderby el.Denumire
                select el;

            Console.WriteLine("Serviciile din categoria reparatie cu pretul mai mic sau egal cu 200 extrase sunt:");
            foreach (ProdusAbstract s in interogare_linq)
                Console.WriteLine(s.ToString());
        }

        public void Interogare3()
        {
            var interogare_linq =
            from elem in elemente
            orderby elem.Denumire
            group elem by elem.Categorie into gr
            select gr;
            foreach (var gr in interogare_linq)
            {
                Console.WriteLine("Categoria " + gr.Key + " :");
                foreach (ProdusAbstract elem in gr)
                {
                    Console.WriteLine(elem.ToString());
                }
            }
        }
    }
}
